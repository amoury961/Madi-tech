import React from "react";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <main className="bg-black text-white min-h-screen px-6 py-10 font-sans">
      {/* Header */}
      <header className="flex justify-between items-center mb-12">
        <h1 className="text-2xl font-bold text-purple-400">MADI TECH</h1>
        <nav className="space-x-6 hidden md:flex">
          <a href="#about" className="hover:text-pink-400">ABOUT US</a>
          <a href="#services" className="hover:text-pink-400">SERVICES</a>
          <a href="#creators" className="hover:text-pink-400">OUR CREATORS</a>
          <a href="#join" className="hover:text-pink-400">JOIN US</a>
          <a href="#contact" className="hover:text-pink-400">CONTACT</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center mb-20">
        <h2 className="text-4xl md:text-5xl font-bold mb-4">
          We connect creators with opportunities.
        </h2>
        <p className="text-pink-400 text-lg mb-6">Grow, promote, and protect.</p>
        <div className="space-x-4">
          <Button className="bg-white text-black hover:bg-gray-200">JOIN AS A CREATOR</Button>
          <Button className="bg-pink-500 text-white hover:bg-pink-600">BOOK A CAMPAIGN</Button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="mb-20">
        <h3 className="text-2xl font-bold mb-4">ABOUT US / من نحن</h3>
        <p className="text-gray-300 max-w-3xl">
          We support creators and craft innovative campaigns. Learn about our mission,
          values, and the team behind our agency.
        </p>
      </section>

      {/* Services */}
      <section id="services" className="mb-20">
        <h3 className="text-2xl font-bold mb-6">OUR SERVICES / خدماتنا</h3>
        <ul className="space-y-2 text-gray-300 list-disc list-inside">
          <li>Talent Management / إدارة المواهب</li>
          <li>Account Growth / نمو الحسابات</li>
          <li>Campaign Planning / تخطيط الحملات</li>
          <li>Content Optimization / تحسين المحتوى</li>
          <li>Brand Partnerships / شراكات العلامات التجارية</li>
        </ul>
      </section>

      {/* Creators */}
      <section id="creators" className="mb-20">
        <h3 className="text-2xl font-bold mb-6">JOIN CREATORS / نماذج</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="text-center">
            <img src="/creator1.jpg" className="rounded-full w-24 h-24 mx-auto mb-2" alt="Creator 1" />
            <p>5.3M / متابعون</p>
          </div>
          <div className="text-center">
            <img src="/creator2.jpg" className="rounded-full w-24 h-24 mx-auto mb-2" alt="Creator 2" />
            <p>2.8M / إنخراطات</p>
          </div>
          <div className="text-center">
            <img src="/creator3.jpg" className="rounded-full w-24 h-24 mx-auto mb-2" alt="Creator 3" />
            <p>1.9M / إحالي</p>
          </div>
        </div>
      </section>

      {/* Join Form */}
      <section id="join" className="mb-20">
        <h3 className="text-2xl font-bold mb-6">JOIN US / إنضم معنا</h3>
        <form className="max-w-md space-y-4">
          <input className="w-full p-2 bg-gray-800 rounded" type="text" placeholder="Name" />
          <input className="w-full p-2 bg-gray-800 rounded" type="text" placeholder="TikTok Profile" />
          <input className="w-full p-2 bg-gray-800 rounded" type="email" placeholder="Email" />
          <input className="w-full p-2 bg-gray-800 rounded" type="text" placeholder="Audience Size" />
          <Button className="w-full bg-pink-500 hover:bg-pink-600">SUBMIT</Button>
        </form>
      </section>

      {/* Contact */}
      <footer id="contact" className="text-center text-gray-400">
        <p>info@maditechagency.com</p>
        <p>+1 234 567 8300</p>
        <div className="flex justify-center space-x-4 mt-4">
          <a href="#"><img src="/tiktok-icon.svg" className="w-6" alt="TikTok" /></a>
          <a href="#"><img src="/instagram-icon.svg" className="w-6" alt="Instagram" /></a>
        </div>
      </footer>
    </main>
  );
}
